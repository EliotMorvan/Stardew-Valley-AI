package stardewvalleyautomaton;

import stardewvalleyautomaton.IHM.IHM_Moteur;

/**
 *
 * @author simonetma
 */
public class StardewValleyAutomaton {

    public static void main(String[] args) {

        IHM_Moteur.demarrer();

    }

}
