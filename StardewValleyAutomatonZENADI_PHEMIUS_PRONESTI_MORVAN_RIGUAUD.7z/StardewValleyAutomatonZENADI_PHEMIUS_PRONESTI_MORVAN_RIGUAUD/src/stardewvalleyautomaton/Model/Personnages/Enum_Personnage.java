/*
* Liste des types de personnages possibles
*/
package stardewvalleyautomaton.Model.Personnages;

/**
 *
 * @author simonetma
 */
public enum Enum_Personnage {
    Poule,
    Abigail,
    grosseBerta,
    Vache;
}
