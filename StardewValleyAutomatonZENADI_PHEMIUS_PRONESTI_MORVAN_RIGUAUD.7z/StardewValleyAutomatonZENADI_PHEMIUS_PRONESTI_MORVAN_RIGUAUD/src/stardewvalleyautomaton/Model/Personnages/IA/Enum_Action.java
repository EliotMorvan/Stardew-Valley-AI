/*
 * liste des actions possibles
 */
package stardewvalleyautomaton.Model.Personnages.IA;

/**
 *
 * @author Matthieu
 */
public enum Enum_Action {
    attendre,
    moveLeft,
    moveRight,
    moveTop,
    moveBottom,
    pondre,
    produireLait,
    traire,
    produireFromage,
    collecterOeuf;
}
