/*
 * liste des types d'objets possibles
 */
package stardewvalleyautomaton.Model.Objets;

/**
 *
 * @author Matthieu
 */
public enum Enum_Objet {
    Arbre,
    Barriere,
    Oeuf,
    Maison,
    Machine_Fromage;
}
