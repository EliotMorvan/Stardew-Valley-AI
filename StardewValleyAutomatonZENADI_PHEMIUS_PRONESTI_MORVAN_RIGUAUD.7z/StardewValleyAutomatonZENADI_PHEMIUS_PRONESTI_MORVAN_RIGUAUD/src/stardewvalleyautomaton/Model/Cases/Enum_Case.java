/*
 * liste des types possibles de case
 */
package stardewvalleyautomaton.Model.Cases;

/**
 *
 * @author simonetma
 */
public enum Enum_Case {
    grass,
    lightgrass,
    dirt;
}
