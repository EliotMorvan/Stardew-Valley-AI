/*
 * Liste des types de sprites
 */
package stardewvalleyautomaton.IHM.Sprites;

/**
 *
 * @author Matthieu
 */
public enum Enum_IHM_Sprite {
    IHM_Dirt,
    IHM_Grass,
    IHM_LightGrass,
    IHM_Arbre,
    IHM_Barriere,
    IHM_Oeuf,
    IHM_Maison,
    IHM_Fromage,
    IHM_Poule,
    IHM_Abigail,
    IHM_grosseBerta,
    IHM_Vache,
    IHM_Vide;
}
